README -- Assignment 1
Authors: Dan Seaman, Dean Shifilliti, Kenedi Heather, Everett Harding

USAGE: Must be run on Python 3.5 or later (NOT Python 2)
The entry point is the astar.py file. Run it from the command line followed by the file path to the board you want to run it on,
and finally by the number of the heuristic function you want to use, numbered 1-6. THERE IS NO ERROR CHECKING. Be careful. Example:
user$: python3 astar.py map.txt 4
This isxample with run the program on a board file called "map.txt" using heuristic 4. 

OUTPUT:
Time to Solve
Score of Path
Number of Moves Made
Number of Nodes Expanded
Branching Factor
Move Sequence

WARNINGS: 
MUST BE RUN ON PYTHON 3
No error checking to make sure boards are implemented correctly
No error checking to make sure command line commands are input correctly
