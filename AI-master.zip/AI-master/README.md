Assignments submitted for CS4341 - Aritificial Intelligence. 

Collaborators:
 - Kenedi Heather
 - Everett Harding
 - Dean Schifilliti
 - Dan Seaman